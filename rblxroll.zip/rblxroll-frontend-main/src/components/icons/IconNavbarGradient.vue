<template>
    <svg width="23" height="14" viewBox="0 0 23 14" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect y="0.947266" width="23" height="2.42105" fill="#D9D9D9"/>
        <rect y="0.947266" width="23" height="2.42105" fill="url(#icon-navbar-gradient-1)"/>
        <rect y="5.78906" width="23" height="2.42105" fill="#D9D9D9"/>
        <rect y="5.78906" width="23" height="2.42105" fill="url(#icon-navbar-gradient-2)"/>
        <rect y="10.6318" width="23" height="2.42105" fill="#D9D9D9"/>
        <rect y="10.6318" width="23" height="2.42105" fill="url(#icon-navbar-gradient-3)"/>
        <defs>
            <linearGradient id="icon-navbar-gradient-1" x1="23" y1="0.947266" x2="18.5398" y2="11.3315" gradientUnits="userSpaceOnUse">
                <stop stop-color="#00ffc2"/>
                <stop offset="1" stop-color="#00aa6d"/>
            </linearGradient>
            <linearGradient id="icon-navbar-gradient-2" x1="23" y1="5.78906" x2="18.5398" y2="16.1733" gradientUnits="userSpaceOnUse">
                <stop stop-color="#00ffc2"/>
                <stop offset="1" stop-color="#00aa6d"/>
            </linearGradient>
            <linearGradient id="icon-navbar-gradient-3" x1="23" y1="10.6318" x2="18.5398" y2="21.016" gradientUnits="userSpaceOnUse">
                <stop stop-color="#00ffc2"/>
                <stop offset="1" stop-color="#00aa6d"/>
            </linearGradient>
        </defs>
    </svg>
</template>
