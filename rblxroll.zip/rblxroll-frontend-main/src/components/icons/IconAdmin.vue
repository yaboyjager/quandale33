<template>
    <svg width="18" height="15" viewBox="0 0 18 15" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M18 3.28378L13.5349 4.87492L13.8007 5.4065C14.1791 6.16415 13.8144 7.09976 12.8349 7.37211C12.8225 7.37622 11.4658 7.74042 11.0537 6.50623L10.6566 5.31324L11.7867 4.18261L8.99793 0L6.20916 4.18261L7.3393 5.31324L6.94216 6.50623C6.68511 7.27629 6.13345 7.5359 5.15578 7.34996C5.04902 7.29795 4.49149 7.27379 4.17607 6.5871C4.00197 6.20902 4.00918 5.77892 4.19513 5.4065L4.46041 4.87541L0 3.28325L1.99005 10.9727H6.66967L8.99793 8.64442L11.3262 10.9727H16.0069L18 3.28378Z" fill="black" />
        <path d="M18 3.28378L13.5349 4.87492L13.8007 5.4065C14.1791 6.16415 13.8144 7.09976 12.8349 7.37211C12.8225 7.37622 11.4658 7.74042 11.0537 6.50623L10.6566 5.31324L11.7867 4.18261L8.99793 0L6.20916 4.18261L7.3393 5.31324L6.94216 6.50623C6.68511 7.27629 6.13345 7.5359 5.15578 7.34996C5.04902 7.29795 4.49149 7.27379 4.17607 6.5871C4.00197 6.20902 4.00918 5.77892 4.19513 5.4065L4.46041 4.87541L0 3.28325L1.99005 10.9727H6.66967L8.99793 8.64442L11.3262 10.9727H16.0069L18 3.28378Z" fill="url(#icon-admin-gradient-1)" />
        <path d="M7.63184 11.4998L8.99562 10.136L10.3594 11.4998L8.99562 12.8635L7.63184 11.4998Z" fill="black" />
        <path d="M7.63184 11.4998L8.99562 10.136L10.3594 11.4998L8.99562 12.8635L7.63184 11.4998Z" fill="url(#icon-admin-gradient-2)" />
        <path d="M6.66988 12.0276H2.14111V14.1374H8.77973L6.66988 12.0276Z" fill="black" />
        <path d="M6.66988 12.0276H2.14111V14.1374H8.77973L6.66988 12.0276Z" fill="url(#icon-admin-gradient-3)" />
        <path d="M15.8549 12.0276H11.3262L9.21631 14.1374H15.8549V12.0276Z" fill="black"/>
        <path d="M15.8549 12.0276H11.3262L9.21631 14.1374H15.8549V12.0276Z" fill="url(#icon-admin-gradient-4)" />
        <defs>
            <linearGradient id="icon-admin-gradient-1" x1="18" y1="0" x2="-1.29306" y2="7.75634" gradientUnits="userSpaceOnUse">
                <stop stop-color="#00ffc2"/>
                <stop offset="1" stop-color="#00aa6d"/>
            </linearGradient>
            <linearGradient id="icon-admin-gradient-2" x1="8.99562" y1="10.136" x2="7.78637" y2="12.1303" gradientUnits="userSpaceOnUse">
                <stop stop-color="#00ffc2"/>
                <stop offset="1" stop-color="#00aa6d"/>
            </linearGradient>
            <linearGradient id="icon-admin-gradient-3" x1="8.77973" y1="12.0276" x2="3.59635" y2="16.0246" gradientUnits="userSpaceOnUse">
                <stop stop-color="#00ffc2"/>
                <stop offset="1" stop-color="#00aa6d"/>
            </linearGradient>
            <linearGradient id="icon-admin-gradient-4" x1="15.8549" y1="12.0276" x2="10.6715" y2="16.0246" gradientUnits="userSpaceOnUse">
                <stop stop-color="#00ffc2"/>
                <stop offset="1" stop-color="#00aa6d"/>
            </linearGradient>
        </defs>
    </svg>
</template>
