<template>
    <svg width="15" height="20" viewBox="0 0 15 20" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M8.81981 0.530518L5.71436 2.83419L8.81257 3.57665L8.81981 0.530518Z" fill="black"/>
        <path d="M8.81981 0.530518L5.71436 2.83419L8.81257 3.57665L8.81981 0.530518Z" fill="url(#icon-diamond-gradient-1)"/>
        <path d="M14.4978 9.70919L13.4016 4.46509L11.604 8.1261L14.4978 9.70919Z" fill="black"/>
        <path d="M14.4978 9.70919L13.4016 4.46509L11.604 8.1261L14.4978 9.70919Z" fill="url(#icon-diamond-gradient-2)"/>
        <path d="M8.57792 3.93618L5.26426 3.14209L1.87793 4.5784L4.52875 7.34216L8.57792 3.93618Z" fill="black"/>
        <path d="M8.57792 3.93618L5.26426 3.14209L1.87793 4.5784L4.52875 7.34216L8.57792 3.93618Z" fill="url(#icon-diamond-gradient-3)"/>
        <path d="M4.55322 10.9044L11.0538 8.11128L8.95346 4.15039L4.71157 7.71775L4.55322 10.9044Z" fill="black"/>
        <path d="M4.55322 10.9044L11.0538 8.11128L8.95346 4.15039L4.71157 7.71775L4.55322 10.9044Z" fill="url(#icon-diamond-gradient-4)"/>
        <path d="M4.65576 11.3002L6.47792 13.621L13.7784 15.456L11.2194 8.47998L4.65576 11.3002Z" fill="black"/>
        <path d="M4.65576 11.3002L6.47792 13.621L13.7784 15.456L11.2194 8.47998L4.65576 11.3002Z" fill="url(#icon-diamond-gradient-5)"/>
        <path d="M6.15742 13.8662L4.27667 11.4707L0.429688 13.332L1.66555 17.7967L6.02236 17.2937L6.15742 13.8662Z" fill="black"/>
        <path d="M6.15742 13.8662L4.27667 11.4707L0.429688 13.332L1.66555 17.7967L6.02236 17.2937L6.15742 13.8662Z" fill="url(#icon-diamond-gradient-6)"/>
        <path d="M6.42529 17.3266L11.8946 18.9792L13.7848 15.8743L6.55412 14.0569L6.42529 17.3266Z" fill="black"/>
        <path d="M6.42529 17.3266L11.8946 18.9792L13.7848 15.8743L6.55412 14.0569L6.42529 17.3266Z" fill="url(#icon-diamond-gradient-7)"/>
        <path d="M14.0014 14.8867L14.5688 10.2084L11.7119 8.64551L14.0014 14.8867Z" fill="black"/>
        <path d="M14.0014 14.8867L14.5688 10.2084L11.7119 8.64551L14.0014 14.8867Z" fill="url(#icon-diamond-gradient-8)"/>
        <path d="M2.21436 18.1405L5.39785 19.7347L10.979 19.1247L6.19947 17.6804L2.21436 18.1405Z" fill="black"/>
        <path d="M2.21436 18.1405L5.39785 19.7347L10.979 19.1247L6.19947 17.6804L2.21436 18.1405Z" fill="url(#icon-diamond-gradient-9)"/>
        <path d="M13.2277 3.90146L9.22444 0.55957L9.2168 3.78298L11.3292 7.7653L13.2277 3.90146Z" fill="black"/>
        <path d="M13.2277 3.90146L9.22444 0.55957L9.2168 3.78298L11.3292 7.7653L13.2277 3.90146Z" fill="url(#icon-diamond-gradient-10)"/>
        <path d="M4.3078 7.69612L1.66684 4.94238L0.448242 12.8739L4.1393 11.0881L4.3078 7.69612ZM2.12248 7.42058L1.67315 10.1269C1.6688 10.1531 1.65933 10.1782 1.64529 10.2007C1.63125 10.2233 1.61291 10.2428 1.59131 10.2583C1.56972 10.2737 1.54529 10.2847 1.51943 10.2908C1.49356 10.2968 1.46677 10.2976 1.44058 10.2933C1.41439 10.2889 1.38931 10.2794 1.36677 10.2654C1.34424 10.2514 1.32469 10.233 1.30924 10.2114C1.2938 10.1898 1.28276 10.1654 1.27675 10.1395C1.27075 10.1137 1.26989 10.0869 1.27424 10.0607L1.72349 7.35435C1.73228 7.30145 1.76171 7.25421 1.80533 7.22301C1.84894 7.19182 1.90317 7.17923 1.95606 7.18801C2.00896 7.19679 2.05621 7.22623 2.0874 7.26985C2.11859 7.31346 2.13118 7.36768 2.1224 7.42058H2.12248ZM2.27493 6.50235L2.25067 6.64792C2.24188 6.70082 2.21243 6.74806 2.16881 6.77925C2.1252 6.81044 2.07097 6.82302 2.01807 6.81424C1.96518 6.80545 1.91793 6.776 1.88674 6.73238C1.85555 6.68877 1.84297 6.63454 1.85176 6.58164L1.87602 6.43607C1.88481 6.38317 1.91425 6.33593 1.95787 6.30474C2.00149 6.27355 2.05571 6.26097 2.10861 6.26976C2.16151 6.27854 2.20875 6.30799 2.23994 6.35161C2.27113 6.39523 2.28372 6.44945 2.27493 6.50235Z" fill="black"/>
        <path d="M4.3078 7.69612L1.66684 4.94238L0.448242 12.8739L4.1393 11.0881L4.3078 7.69612ZM2.12248 7.42058L1.67315 10.1269C1.6688 10.1531 1.65933 10.1782 1.64529 10.2007C1.63125 10.2233 1.61291 10.2428 1.59131 10.2583C1.56972 10.2737 1.54529 10.2847 1.51943 10.2908C1.49356 10.2968 1.46677 10.2976 1.44058 10.2933C1.41439 10.2889 1.38931 10.2794 1.36677 10.2654C1.34424 10.2514 1.32469 10.233 1.30924 10.2114C1.2938 10.1898 1.28276 10.1654 1.27675 10.1395C1.27075 10.1137 1.26989 10.0869 1.27424 10.0607L1.72349 7.35435C1.73228 7.30145 1.76171 7.25421 1.80533 7.22301C1.84894 7.19182 1.90317 7.17923 1.95606 7.18801C2.00896 7.19679 2.05621 7.22623 2.0874 7.26985C2.11859 7.31346 2.13118 7.36768 2.1224 7.42058H2.12248ZM2.27493 6.50235L2.25067 6.64792C2.24188 6.70082 2.21243 6.74806 2.16881 6.77925C2.1252 6.81044 2.07097 6.82302 2.01807 6.81424C1.96518 6.80545 1.91793 6.776 1.88674 6.73238C1.85555 6.68877 1.84297 6.63454 1.85176 6.58164L1.87602 6.43607C1.88481 6.38317 1.91425 6.33593 1.95787 6.30474C2.00149 6.27355 2.05571 6.26097 2.10861 6.26976C2.16151 6.27854 2.20875 6.30799 2.23994 6.35161C2.27113 6.39523 2.28372 6.44945 2.27493 6.50235Z" fill="url(#icon-diamond-gradient-11)"/>
        <defs>
            <linearGradient id="icon-diamond-gradient-1" x1="8.37617" y1="1.38724" x2="5.84211" y2="1.20722" gradientUnits="userSpaceOnUse">
                <stop stop-color="#6953f1"/>
                <stop offset="1" stop-color="#a3a3b4"/>
            </linearGradient>
            <linearGradient id="icon-diamond-gradient-2" x1="14.0844" y1="5.93999" x2="11.7146" y2="5.84887" gradientUnits="userSpaceOnUse">
                <stop stop-color="#6953f1"/>
                <stop offset="1" stop-color="#a3a3b4"/>
            </linearGradient>
            <linearGradient id="icon-diamond-gradient-3" x1="7.62078" y1="4.32336" x2="2.19303" y2="3.72" gradientUnits="userSpaceOnUse">
                <stop stop-color="#6953f1"/>
                <stop offset="1" stop-color="#a3a3b4"/>
            </linearGradient>
            <linearGradient id="icon-diamond-gradient-4" x1="10.1252" y1="6.04994" x2="4.81775" y2="5.69397" gradientUnits="userSpaceOnUse">
                <stop stop-color="#6953f1"/>
                <stop offset="1" stop-color="#a3a3b4"/>
            </linearGradient>
            <linearGradient id="icon-diamond-gradient-5" x1="12.4752" y1="10.442" x2="5.0551" y2="9.76581" gradientUnits="userSpaceOnUse">
                <stop stop-color="#6953f1"/>
                <stop offset="1" stop-color="#a3a3b4"/>
            </linearGradient>
            <linearGradient id="icon-diamond-gradient-6" x1="5.33917" y1="13.2499" x2="0.660354" y2="12.9547" gradientUnits="userSpaceOnUse">
                <stop stop-color="#6953f1"/>
                <stop offset="1" stop-color="#a3a3b4"/>
            </linearGradient>
            <linearGradient id="icon-diamond-gradient-7" x1="12.7334" y1="15.4413" x2="6.76256" y2="14.8192" gradientUnits="userSpaceOnUse">
                <stop stop-color="#6953f1"/>
                <stop offset="1" stop-color="#a3a3b4"/>
            </linearGradient>
            <linearGradient id="icon-diamond-gradient-8" x1="14.1607" y1="10.4008" x2="11.8201" y2="10.3262" gradientUnits="userSpaceOnUse">
                <stop stop-color="#6953f1"/>
                <stop offset="1" stop-color="#a3a3b4"/>
            </linearGradient>
            <linearGradient id="icon-diamond-gradient-9" x1="9.72691" y1="18.2582" x2="3.12262" y2="16.2946" gradientUnits="userSpaceOnUse">
                <stop stop-color="#6953f1"/>
                <stop offset="1" stop-color="#a3a3b4"/>
            </linearGradient>
            <linearGradient id="icon-diamond-gradient-10" x1="12.6548" y1="2.58618" x2="9.37022" y2="2.45878" gradientUnits="userSpaceOnUse">
                <stop stop-color="#6953f1"/>
                <stop offset="1" stop-color="#a3a3b4"/>
            </linearGradient>
            <linearGradient id="icon-diamond-gradient-11" x1="3.75643" y1="7.17313" x2="0.594758" y2="7.06593" gradientUnits="userSpaceOnUse">
                <stop stop-color="#6953f1"/>
                <stop offset="1" stop-color="#a3a3b4"/>
            </linearGradient>
        </defs>
    </svg>
</template>
