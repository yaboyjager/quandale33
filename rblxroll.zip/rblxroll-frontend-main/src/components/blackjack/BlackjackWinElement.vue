<template>
    <div class="blackjack-win-element">
        <div class="element-amount">

        </div>
        <div class="element-info">
            
        </div>
    </div>
</template>

<script>
    export default {
        name: 'BlackjackWinElement'
    }
</script>

<style scoped>
    .blackjack-win-element {
        display: flex;
        align-items: center;
    }

    .blackjack-win-element .element-amount {
        margin-right: 8px;
    }
    
    .blackjack-win-element .element-info {

    }
</style>